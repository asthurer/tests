/*********************************************************************
 * Script:      LogManager.java
 * Deliverable: AXPOLoggingFramework SR-XXXX
 * Description: This script would 		
 * Revision History
 * -------------------------------------------------------------------
 * SNo.   Name         Date       Description
 * 1.0    aagr18     dd MMM-YY    		
 ********************************************************************/

package com.axpo.loggings;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;



/**
 * @author  aagr18
 * @created dd MMM-YY
 * @version 1.0
 * 
 *          Description-
 *          This class would be used to handle logging by the implementing project		
 */

public class LogManager
{
    public static org.slf4j.Logger getLogger(Class<?> className){
        org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(className);
        return logger;
    }
    

    
    /**
     * @author  aagr18
     * @version 1.0
     * 
     *          Description-
     *          This method would be used to set the configuration file for the logger.	
     *
     * @param configFile
     * @throws Exception
     */
    public static void setConfigFile(String configFile) throws Exception{
        LoggerContext lc = (LoggerContext) org.slf4j.LoggerFactory.getILoggerFactory();
        JoranConfigurator configurator = new JoranConfigurator();
        lc.reset();
        configurator.setContext(lc);
        try
        {
            configurator.doConfigure(configFile);            
        }
        catch (JoranException e)
        {
            throw new Exception(e);
        }         
    }
    
    
    
    /**
     * @author  aagr18
     * @version 1.0
     * 
     *          Description- 
     *          This method would be used to set the default log level which is Debug by default for root	
     *
     * @param minLogLevel
     */
    public static void setLevel(Level newLogLevel){
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        Logger logger = context.getLogger("ROOT");
        logger.setLevel(newLogLevel.getLevel());
    }
}
