/*********************************************************************
 * Script:      Level.java
 * Deliverable: AXPOLoggingFramework SR-XXXX
 * Description: This script would 		
 * Revision History
 * -------------------------------------------------------------------
 * SNo.   Name         Date       Description
 * 1.0    aagr18     dd MMM-YY    		
 ********************************************************************/

package com.axpo.loggings;

/**
 * @author aagr18
 * @created dd MMM-YY
 * @version 1.0
 * 
 *          Description-
 *          This enum would be used to wrap the logback Levels
 */

public enum Level
{
    TRACE(ch.qos.logback.classic.Level.TRACE), DEBUG(ch.qos.logback.classic.Level.DEBUG), INFO(ch.qos.logback.classic.Level.ERROR), WARN(
        ch.qos.logback.classic.Level.WARN), ERROR(ch.qos.logback.classic.Level.ERROR), OFF(ch.qos.logback.classic.Level.OFF);

    private ch.qos.logback.classic.Level level;

    /**
     * 
     */
    private Level(ch.qos.logback.classic.Level level)
    {
        this.level = level;
    }

    public ch.qos.logback.classic.Level getLevel()
    {
        return this.level;
    }
}
