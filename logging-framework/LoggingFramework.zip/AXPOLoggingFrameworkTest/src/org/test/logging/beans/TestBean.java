package org.test.logging.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.test.logging.beans.TestBean;


public class TestBean {
	private static final Logger logger = LoggerFactory.getLogger(TestBean.class);
	
	public void sayMarco() {
		String msg = "I'm Marco";
		int i = 0;
		//while(i!=99999){
		    i++;
    		logger.debug("Debugging Message", msg);
    		logger.info("Hello there. I am {}", msg);
    		logger.warn("warning message");
    		logger.error("error message");
		//}
	}
}
