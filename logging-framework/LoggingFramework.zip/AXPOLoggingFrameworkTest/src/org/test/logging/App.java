package org.test.logging;

import org.slf4j.Logger;
import org.test.logging.beans.TestBean;

import com.axpo.loggings.LogManager;


public class App {
    private static final Logger logger = LogManager.getLogger(App.class);
    
    public static void main(String[] args) {
        
        try
        {
           // AXPOLogger.setConfigFile("D:\\sapient\\endur\\workspace\\AXPOLoggingFrameworkTest\\src\\custom.xml");
        }
        catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        TestBean poloBean = new TestBean();
        poloBean.sayMarco();
        
        logger.debug("I am Polo");
    }
} 
